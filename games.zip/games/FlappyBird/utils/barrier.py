import pygame
from pygame.sprite import Sprite


class Barrier(Sprite):
    """表示单个障碍物的类"""

    def __init__(self, game):
        """初始化障碍物并设置其初始位置"""
        super().__init__()
        self.game = game
        self.screen = game.screen
        self.screen_rect = self.screen.get_rect()

        # 加载障碍物图像并设置其rect属性
        self.image = pygame.image.load("images/barrier.png").convert_alpha()
        self.rect = self.image.get_rect()

        # 每个障碍物都放到屏幕中央偏右
        self.rect.centery = self.screen_rect.centery
        self.rect.centerx = self.screen_rect.centerx + 250

        self.past_bird = False

    def update(self):
        """向左移动障碍物"""
        if self.game.bird.living:
            self.rect.x -= self.game.settings.barrier_speed
