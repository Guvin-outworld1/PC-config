import pygame.mixer


class Settings:
    def __init__(self):
        self.bg_color = "#66a7ee"
        self.width = 1000
        self.height = 600

        # 飞翔初始速度
        self.bird_fly_speed = 58

        # 下落速度
        self.bird_drop_speed = 3.7

        # 障碍物速度
        self.barrier_speed = 4

        # 游戏状态
        self.game_running = False
        self.score = 0
        self.is_get_high = False

        # 音效
        self.score_add_sound = pygame.mixer.Sound(r"audio/get_score.wav")

        # 史上最高分
        with open(r"utils/high_score.txt", "r") as f:
            f.seek(0)
            self.high_score = int(f.read())

    def reset_game(self):
        self.game_running = True
        self.bird_drop_speed = 4
        self.score = 0
        self.is_get_high = False
