import pygame


class Bird:
    """管理鸟的类"""

    def __init__(self, game):
        """初始化鸟并设置其初始位置"""
        self.settings = game.settings
        self.screen = game.screen
        self.screen_rect = self.screen.get_rect()

        # 加载鸟并获得其外接矩形
        self.image = pygame.image.load("images/real_bird.png").convert_alpha()
        self.rect = self.image.get_rect()

        # 每只新鸟都将其放在屏幕偏左中央
        self.rect.centery = self.screen_rect.centery - 70
        self.rect.x = 70

        # 设置运动状态
        self.flying = False
        self.dropping = True

        # 鸟死了没有
        self.living = True

    def fly(self):
        if self.flying and self.living and self.rect.top > 0:
            self.fly_speed = self.settings.bird_fly_speed
            self.rect.y -= self.fly_speed
            self.fly_speed += 3
            if self.fly_speed > 60:
                self.flying = False
                self.fly_speed = self.settings.bird_fly_speed

    def drop(self):
        if not self.living:
            self.settings.bird_drop_speed *= 1.19
        if self.dropping:
            self.rect.y += self.settings.bird_drop_speed

    def blitme(self):
        """在指定位置绘制鸟"""

        self.screen.blit(self.image, self.rect)

    def center_bird(self):
        """每只新鸟都将其放在屏幕偏左中央"""
        self.rect.centery = self.screen_rect.centery
        self.rect.x = 70
