class GameStats:
    def __init__(self):
        pass
