import pygame.font


class ScoreBoard:
    """计分板的类"""

    def __init__(self, game):
        """初始化计分板"""
        self.game = game
        self.screen = game.screen
        self.screen_rect = self.screen.get_rect()
        self.settings = game.settings

        self.width, self.height = 100, 100
        self.text_color = "#391663"
        self.font = pygame.font.SysFont(None, 50)
        self.prep_score()

    def prep_score(self):
        """将分数渲染成图像"""
        score_str = "score: " + str(self.settings.score)
        self.image = self.font.render(
            score_str, True, self.text_color, self.settings.bg_color
        )

        # 将分数放在小鸟头上
        self.rect = self.image.get_rect()
        self.rect.x = self.game.bird.rect.x
        self.rect.y = 0

    def show_score(self):
        self.screen.blit(self.image, self.rect)

    def prep_high_score(self):
        """将最高分渲染图像"""
        high_score_str = f"High Score: {self.settings.high_score:,}"
        self.high_score_image = self.font.render(
            high_score_str, False, self.text_color, "#ffbf32"
        )

        # 将最高分放在屏幕上部中央
        self.high_score_rect = self.high_score_image.get_rect()
        self.high_score_rect.centerx = self.screen_rect.centerx
        self.high_score_rect.y = self.screen_rect.centery - 200

        self.screen.blit(self.high_score_image, self.high_score_rect)

    def check_high_score(self):
        """检查是否诞生了新的最高分"""
        if self.settings.score > self.settings.high_score:
            self.settings.high_score = self.settings.score
            if not self.settings.is_get_high:
                self.settings.score_add_sound = pygame.mixer.Sound(
                    r"audio/get_high_score.wav"
                )
            self.settings.is_get_high = True
