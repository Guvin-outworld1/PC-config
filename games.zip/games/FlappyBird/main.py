import os
import random
import sys

# 将工作目录切换到当前文件所在目录
os.chdir(os.path.dirname(os.path.abspath(__file__)))

import pygame
from utils.barrier import Barrier
from utils.bird import Bird
from utils.scoreboard import ScoreBoard
from utils.settings import Settings
from utils.start_button import StartButton


class Main:
    """飞翔的小鸟，管理游戏资源和行为的类"""

    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        self.clock = pygame.time.Clock()
        self.settings = Settings()

        self.screen = pygame.display.set_mode(
            (self.settings.width, self.settings.height)
        )
        self.screen_rect = self.screen.get_rect()
        pygame.display.set_caption("Flappy Bird")

        # 实例化鸟、障碍物群和云群
        self.bird = Bird(self)
        self.barriers = pygame.sprite.Group()

        # 实例化开始按钮
        self.start_game_button = StartButton(self)

        # 实例化计分板
        self.sb = ScoreBoard(self)

        pygame.mixer.music.load(r"audio\bgm.wav")

    def run_game(self):
        while True:
            self.clock.tick(30)

            self._check_events()
            if self.settings.game_running:
                self.bird.fly()
                self.bird.drop()
                self.barriers.update()
            self._update_screen()

    def _check_events(self):
        """检测键盘和鼠标事件"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                with open(r"utils/high_score.txt", "w") as f:
                    f.write(str(self.settings.high_score))
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.bird.flying = True
                mouse_pos = pygame.mouse.get_pos()
                self._check_play_button(mouse_pos)

            elif event.type == pygame.KEYUP:
                self._check_keyup(event)
            elif event.type == pygame.KEYDOWN:
                self._check_keydown(event)

    def _game_start(self):
        pygame.mixer.music.play(-1)
        self.settings.reset_game()
        self.sb.prep_score()

        pygame.time.delay(100)

        # 清空剩余的障碍物群
        self.barriers.empty()
        # 创建第一个障碍物群
        self._init_create_barriers()
        # 让鸟活
        self.bird.living = True
        self.bird.image = pygame.image.load(
            "images/real_bird.png"
        ).convert_alpha()

        self.bird.center_bird()

    def _check_play_button(self, mouse_pos):
        """点击开始按钮"""
        if (
            self.start_game_button.rect.collidepoint(mouse_pos)
            and not self.settings.game_running
        ):
            self._game_start()

    def _check_keyup(self, event):
        """检测键盘松开"""
        if event.key == pygame.K_UP or pygame.K_SPACE:
            self.bird.flying = True

    def _check_keydown(self, event):
        """检测键盘按下"""
        if not self.settings.game_running and (
            event.key == pygame.K_SPACE or event.key == pygame.K_UP
        ):
            self._game_start()

    def _init_create_barriers(self):
        """第一次创建多个障碍物"""
        # 创建一个障碍物，间距为二倍宽度（100像素）
        barrier_current = 0
        old_y = 12
        # 以25为单位长度，将600平均分，前5、后4份不要。此集合为障碍物的可定范围
        all_posy = {i for i in range(5, 21)}
        while barrier_current <= self.screen_rect.width + 20:
            new_barrier = Barrier(self)
            # 设置y坐标与上一个的差值的集合
            diff_y = {i for i in range(-5, 6)}
            # 设置此次的y坐标的集合
            this_ys = {i + old_y for i in diff_y}
            # 从此次y坐标的集合与可定范围集合中挑一个
            this_y = random.choice(list(this_ys & all_posy))
            new_barrier.rect.centery = this_y * 25
            old_y = this_y

            new_barrier.rect.centerx += barrier_current
            barrier_current += 5 * new_barrier.rect.width
            self.barriers.add(new_barrier)

    def _create_remove_barriers(self):
        """当有一个障碍物超出屏幕左边时，再生成一个障碍物并删除本身"""
        for barrier in self.barriers.copy():
            if barrier.rect.right < self.screen_rect.left:
                old_barrier = list(self.barriers)[-1]
                old_x = old_barrier.rect.centerx
                old_diff_y = old_barrier.rect.centery // 25
                # 以25为单位长度，将600平均分，前、后4份不要。此集合为障碍物的可定范围
                all_posy = {i for i in range(5, 21)}
                new_barrier = Barrier(self)
                # 设置y坐标与上一个的差值的集合
                diff_y = {i for i in range(-6, 7)}
                # 设置此次的y坐标的集合
                this_ys = {i + old_diff_y for i in diff_y}
                # 从此次y坐标的集合与可定范围集合中挑一个
                this_y = random.choice(list(this_ys & all_posy))
                new_barrier.rect.centery = this_y * 25

                new_barrier.rect.centerx = old_x + new_barrier.rect.width * 5
                self.barriers.add(new_barrier)

            if barrier.rect.right < 0:
                self.barriers.remove(barrier)

    def _bird_hit_barriers(self):
        """检测鸟碰到障碍物"""
        collision = pygame.sprite.spritecollide(
            self.bird, self.barriers, False, pygame.sprite.collide_mask
        )
        if collision:
            self.bird.living = False
            self.bird.image = pygame.image.load(
                "images/real_bird_dying.png"
            ).convert_alpha()

    def _bird_die(self):
        """当鸟落到屏幕底部，死亡"""
        if self.bird.rect.bottom >= self.screen_rect.bottom:
            self.settings.game_running = False

    def _score_add(self):
        for barrier in self.barriers:
            if (
                self.bird.rect.left > barrier.rect.right
                and not barrier.past_bird
            ):
                self.settings.score += 1
                self.sb.check_high_score()
                self.settings.score_add_sound.play()
                barrier.past_bird = True
                self.sb.prep_score()

    def _update_screen(self):
        self.screen.fill(self.settings.bg_color)
        if self.settings.game_running:
            self._score_add()
            self._bird_die()
            self._bird_hit_barriers()

        self.barriers.draw(self.screen)
        self._create_remove_barriers()
        self.sb.show_score()
        self.bird.blitme()

        if not self.settings.game_running:
            pygame.mixer.music.stop()
            self.sb.prep_high_score()
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        with open(r"utils/high_score.txt", "w") as f:
                            f.write(str(self.settings.high_score))
                        pygame.quit()
                        sys.exit()

            self.start_game_button.draw_button()

        pygame.display.flip()


if __name__ == "__main__":
    main = Main()
    main.run_game()
