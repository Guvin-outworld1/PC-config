from pygame.sprite import Sprite


class Bullet(Sprite):
    """管理飞船所发射子弹的类"""

    def __init__(self, ai_game):
        """在飞船当前位置创建一个子弹对象"""
        super().__init__()
        self.screen = ai_game.screen
        self.settings = ai_game.settings
        self.image = ai_game.bullet_image
        self.bullet_width = self.image.get_width()
        self.bullet_height = self.image.get_height()

        # 在(0,0)处创建一个子弹, 在设置正确的位置
        self.rect = self.image.get_rect()
        self.rect.midbottom = ai_game.ship.rect.midtop

        # 储存用小数表示子弹的位置
        self.y = float(self.rect.y)

    def update(self):
        """向上移动子弹"""
        # 更新表示子弹位置的小数值
        self.y -= self.settings.bullet_speed
        # 更新表示子弹的rect的位置
        self.rect.y = self.y

    def draw_bullet(self):
        """在屏幕上绘制子弹"""
        self.screen.blit(self.image, self.rect)


class BigBullet(Sprite):
    """管理大子弹的类"""

    def __init__(self, ai_game):
        """在飞船当前位置创建一个子弹对象"""
        super().__init__()
        self.screen = ai_game.screen
        self.settings = ai_game.settings
        self.image = ai_game.big_bullet_image
        self.bullet_width = self.image.get_width()
        self.bullet_height = self.image.get_height()

        # 在(0,0)处创建一个子弹, 在设置正确的位置
        self.rect = self.image.get_rect()
        self.rect.midbottom = ai_game.ship.rect.center

        # 储存用小数表示子弹的位置
        self.y = float(self.rect.y)

    def update(self):
        """向上移动子弹"""
        # 更新表示子弹位置的小数值
        self.y -= self.settings.bullet_speed * 1.05
        # 更新表示子弹的rect的位置
        self.rect.y = self.y

    def draw_bullet(self):
        """在屏幕上绘制大子弹"""
        self.screen.blit(self.image, self.rect)


class PiercingBullet(Sprite):
    """管理透心凉子弹的类"""

    def __init__(self, ai_game):
        """在飞船当前位置创建一个子弹对象"""
        super().__init__()
        self.screen = ai_game.screen
        self.settings = ai_game.settings
        self.image = ai_game.piercing_bullet_image
        self.bullet_width = self.image.get_width()
        self.bullet_height = self.image.get_height()

        # 在(0,0)处创建一个子弹, 在设置正确的位置
        self.rect = self.image.get_rect()
        self.rect.midbottom = ai_game.ship.rect.midtop

        # 储存用小数表示子弹的位置
        self.y = float(self.rect.y)

    def update(self):
        """向上移动子弹"""
        # 更新表示子弹位置的小数值
        self.y -= self.settings.bullet_speed * 1.2
        # 更新表示子弹的rect的位置
        self.rect.y = self.y

    def draw_bullet(self):
        """在屏幕上绘制透心凉子弹"""
        self.screen.blit(self.image, self.rect)
