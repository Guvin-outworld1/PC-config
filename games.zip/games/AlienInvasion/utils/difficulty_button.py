import pygame


class ChooseLabel:
    def __init__(self, ai_game):
        """初始化按钮属性"""
        self.screen = ai_game.screen
        self.screen_rect = self.screen.get_rect()

        # 设置按钮属性及其他设置
        self.width, self.height = 200, 50
        self.button_color = "#5f38d8"
        self.text_color = (255, 255, 255)
        self.font = pygame.font.SysFont(None, 48)

        # 创建按钮的rect属性并使其居中
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.centerx = self.screen_rect.centerx - 270
        self.rect.centery = self.screen_rect.centery - 130

        # 按钮的标签只需创建一次
        self._prep_choose_button()

    def _prep_choose_button(self):
        """将msg渲染成图像并使其在按钮上居中"""
        self.diff_image = self.font.render(
            "Choose the difficulty:", False, self.text_color, self.button_color
        )
        self.diff_image_rect = self.diff_image.get_rect()
        self.diff_image_rect.center = self.rect.center

    def draw_choose_button(self):
        # 绘制一个用颜色填充的按钮，在绘制文本
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.diff_image, self.diff_image_rect)


class Choice:
    def __init__(self, ai_game):
        """初始化按钮属性"""
        self.screen = ai_game.screen
        self.screen_rect = self.screen.get_rect()

        # 设置按钮属性及其他设置
        self.width, self.height = 200, 50
        self.button_color = "#5f38d8"
        self.font = pygame.font.SysFont(None, 48)

        # 创建按钮的rect属性并使其居中
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.centerx = self.screen_rect.centerx
        self.rect.centery = self.screen_rect.centery - 130

        # 按钮的标签只需创建一次
        self.text = "Easy"

        self.prep_choice_button()

    def prep_choice_button(self):
        """将msg渲染成图像并使其再在按钮上居中"""
        if self.text == "Easy":
            self.text_color = "#B8E186"
        if self.text == "Medium":
            self.text_color = "#F5A623"
        if self.text == "Difficulty":
            self.text_color = "#C53030"
        self.image = self.font.render(
            self.text, False, self.text_color, self.button_color
        )
        self.image_rect = self.image.get_rect()
        self.image_rect.center = self.rect.center

    def draw_choice_button(self):
        # 绘制一个用颜色填充的按钮，在绘制文本
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.image, self.image_rect)


class EasyButton:
    def __init__(self, ai_game):
        """初始化按钮属性"""
        self.screen = ai_game.screen
        self.screen_rect = self.screen.get_rect()

        # 设置按钮属性及其他设置
        self.width, self.height = 200, 50
        self.button_color = "#B8E186"
        self.text_color = (255, 255, 255)
        self.font = pygame.font.SysFont(None, 48)

        # 创建按钮的rect属性并使其居中
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.centerx = self.screen_rect.centerx - 210
        self.rect.centery = self.screen_rect.centery - 70

        # 按钮的标签只需创建一次
        self._prep_easy_button()

    def _prep_easy_button(self):
        """将msg渲染成图像并使其再在按钮上居中"""
        self.diff_image = self.font.render(
            "Easy", False, self.text_color, self.button_color
        )
        self.diff_image_rect = self.diff_image.get_rect()
        self.diff_image_rect.center = self.rect.center

    def draw_easy_button(self):
        # 绘制一个用颜色填充的按钮，在绘制文本
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.diff_image, self.diff_image_rect)


class MediumButton:
    def __init__(self, ai_game):
        """初始化按钮属性"""
        self.screen = ai_game.screen
        self.screen_rect = self.screen.get_rect()

        # 设置按钮属性及其他设置'#F5A623'
        self.width, self.height = 200, 50
        self.button_color = "#F5A623"
        self.text_color = (255, 255, 255)
        self.font = pygame.font.SysFont(None, 48)

        # 创建按钮的rect属性并使其居中
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.centerx = self.screen_rect.centerx
        self.rect.centery = self.screen_rect.centery - 70

        # 按钮的标签只需创建一次
        self._prep_medium_button()

    def _prep_medium_button(self):
        """将msg渲染成图像并使其再在按钮上居中"""
        self.diff_image = self.font.render(
            "Medium", False, self.text_color, self.button_color
        )
        self.diff_image_rect = self.diff_image.get_rect()
        self.diff_image_rect.center = self.rect.center

    def draw_medium_button(self):
        # 绘制一个用颜色填充的按钮，在绘制文本
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.diff_image, self.diff_image_rect)


class DifficultButton:
    def __init__(self, ai_game):
        """初始化按钮属性"""
        self.screen = ai_game.screen
        self.screen_rect = self.screen.get_rect()

        # 设置按钮属性及其他设置
        self.width, self.height = 200, 50
        self.button_color = "#C53030"
        self.text_color = (255, 255, 255)
        self.font = pygame.font.SysFont(None, 48)

        # 创建按钮的rect属性并使其居中
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.centerx = self.screen_rect.centerx + 210
        self.rect.centery = self.screen_rect.centery - 70

        # 按钮的标签只需创建一次
        self._prep_difficult_button()

    def _prep_difficult_button(self):
        """将msg渲染成图像并使其再在按钮上居中"""
        self.diff_image = self.font.render(
            "Difficult", False, self.text_color, self.button_color
        )
        self.diff_image_rect = self.diff_image.get_rect()
        self.diff_image_rect.center = self.rect.center

    def draw_difficult_button(self):
        # 绘制一个用颜色填充的按钮，在绘制文本
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.diff_image, self.diff_image_rect)
