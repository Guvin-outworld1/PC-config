import pygame


class Settings(object):
    """存储游戏《外星人入侵》中所有的设置"""

    def __init__(self):
        """初始化游戏的设置"""
        # 屏幕设置
        self.screen_width = 970
        self.screen_height = 800
        self.bg_color = "#5f38d8"

        # 飞船设置
        self.ship_limit = 2

        # 子弹设置
        self.bullets_allowed = 3

        # 外星人设置
        self.fleet_drop_speed = 11

        # 音效设置
        self.shoot_sound = pygame.mixer.Sound("audio/shoot.wav")
        self.explosion_sound = pygame.mixer.Sound("audio/explosion.wav")
        self.ship_hit_sound = pygame.mixer.Sound("audio/ship_hit.wav")
        self.give_bullet_alien_explosion = pygame.mixer.Sound(
            "audio/give_bullet_alien_explosion.wav"
        )

        # bgm设置
        self.bgm1 = pygame.mixer.Sound("audio/bgm1.mp3")
        self.bgm2 = pygame.mixer.Sound("audio/bgm2.mp3")
        self.play_bgm = "bgm1"

        # 难度设置
        self.difficulty = 1

        # 各个难度不同的分数增长率
        self.easy_increment = 3.7
        self.med_increment = 6.1
        self.diff_increment = 101.7

        # 默认分数增加率
        self.increment = self.easy_increment

    def initialize_dynamic_settings(self):
        """初始化随游戏进行而变化的设置"""
        self.ship_speed = 7
        self.bullet_speed = 5
        self.alien_speed = 3 * self.difficulty
        self.fleet_direction = 1  # 1表示右移, -1表示左移

        # 计分
        self.alien_points = 3 * self.increment

    def increase_speed(self):
        """提高速度设置和外星人分数"""
        self.ship_speed *= 1.1
        self.bullet_speed *= 1.2
        self.alien_speed *= 1.15

        self.alien_points = round(self.alien_points * self.increment)
