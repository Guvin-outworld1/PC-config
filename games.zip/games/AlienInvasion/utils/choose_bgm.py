import pygame.font


class ChooseBgmLabel:
    def __init__(self, ai_game):
        """初始化按钮属性"""
        self.screen = ai_game.screen
        self.screen_rect = self.screen.get_rect()

        # 设置按钮属性及其他设置
        self.width, self.height = 200, 50
        self.button_color = "#5f38d8"
        self.text_color = (255, 255, 255)
        self.font = pygame.font.SysFont(None, 48)

        # 创建按钮的rect属性并
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.centerx = self.screen_rect.centerx - 270
        self.rect.centery = self.screen_rect.centery

        # 按钮的标签只需创建一次
        self._prep_choose_button()

    def _prep_choose_button(self):
        """将msg渲染成图像并使其在按钮上居中"""
        self.diff_image = self.font.render(
            "Choose a bgm: ", False, self.text_color, self.button_color
        )
        self.diff_image_rect = self.diff_image.get_rect()
        self.diff_image_rect.center = self.rect.center

    def draw_choose_button(self):
        # 绘制一个用颜色填充的按钮，在绘制文本
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.diff_image, self.diff_image_rect)


class ChoiceBgm:
    def __init__(self, ai_game):
        """初始化按钮属性"""
        self.screen = ai_game.screen
        self.ai_game = ai_game
        self.screen_rect = self.screen.get_rect()

        # 设置按钮属性及其他设置
        self.width, self.height = 200, 50
        self.button_color = "#5f38d8"
        self.font = pygame.font.SysFont(None, 48)

        # 创建按钮的rect属性并使其居中
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.center = self.screen_rect.center

        self.prep_choice_button()

    def prep_choice_button(self):
        """将msg渲染成图像并使其再在按钮上居中"""
        text_color = "#34ea22"
        if self.ai_game.settings.play_bgm == "bgm1":
            text_color = "#34ea22"
        elif self.ai_game.settings.play_bgm == "bgm2":
            text_color = "#44fa22"

        self.image = self.font.render(
            self.ai_game.settings.play_bgm,
            False,
            text_color,
            self.button_color,
        )

        self.image_rect = self.image.get_rect()
        self.image_rect.center = self.rect.center

    def draw_choice_button(self):
        # 绘制一个用颜色填充的按钮，在绘制文本
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.image, self.image_rect)


class ChooseBgm1:
    def __init__(self, ai_game):
        """初始化选择音乐需要的属性"""
        self.ai_game = ai_game
        self.screen = ai_game.screen
        self.screen_rect = ai_game.screen.get_rect()

        # 选择音乐时按钮的属性
        self.width, self.height = 200, 50
        self.button_color = "#34ea22"
        self.text_color = "#3134E9"
        self.font = pygame.font.SysFont(None, 48)

        # 音乐按钮的rect属性
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.x = self.screen_rect.centerx - 210
        self.rect.y = self.screen_rect.centery + 40

        # 按钮只需创建一次
        self._prep_bgm1()

    def _prep_bgm1(self):
        """将bgm1渲染成图像并使其再在按钮上居中"""
        self.bgm1_image = self.font.render(
            "bgm1", False, self.text_color, self.button_color
        )

        self.bgm1_image_rect = self.bgm1_image.get_rect()
        self.bgm1_image_rect.center = self.rect.center

    def draw_bgm1(self):
        # 绘制一个用颜色填充的按钮，再绘制文本
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.bgm1_image, self.bgm1_image_rect)


class ChooseBgm2:
    def __init__(self, ai_game):
        """初始化选择音乐需要的属性"""
        self.ai_game = ai_game
        self.screen = ai_game.screen
        self.screen_rect = ai_game.screen.get_rect()

        # 选择音乐时按钮的属性
        self.width, self.height = 200, 50
        self.button_color = "#44fa22"
        self.text_color = "#e134d9"
        self.font = pygame.font.SysFont(None, 48)

        # 音乐按钮的rect属性
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.x = self.screen_rect.centerx + 10
        self.rect.y = self.screen_rect.centery + 40

        # 按钮只需创建一次
        self._prep_bgm2()

    def _prep_bgm2(self):
        """将bgm1渲染成图像并使其再在按钮上居中"""
        self.bgm2_image = self.font.render(
            "bgm2", False, self.text_color, self.button_color
        )

        self.bgm2_image_rect = self.bgm2_image.get_rect()
        self.bgm2_image_rect.center = self.rect.center

    def draw_bgm2(self):
        # 绘制一个用颜色填充的按钮，再绘制文本
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.bgm2_image, self.bgm2_image_rect)
