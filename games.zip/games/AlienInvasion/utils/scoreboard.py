import pygame.font
from pygame.sprite import Group
from utils.mini_ship import MiniShip


class ScoreBoard:
    """显示得分信息的类"""

    def __init__(self, ai_game):
        """初始化显示得分需要的属性"""
        self.ai_game = ai_game
        self.screen = ai_game.screen
        self.screen_rect = self.screen.get_rect()
        self.settings = ai_game.settings
        self.stats = ai_game.stats

        # 显示得分信息时使用的字体设置
        self.text_color = "#ffbf32"
        self.font = pygame.font.SysFont(None, 32)
        # 初始化得分与最高分的图像
        self.prep_score()
        self.prep_high_score()
        self.prep_level()
        self.prep_mini_ships()

        # 初始化剩余两种特殊子弹的图像
        self.prep_big_bullets()
        self.prep_piercing_bullets()

    def show_score(self):
        """在屏幕上显示得分、最高分、等级、剩余飞船和剩余两种特殊子弹"""
        self.screen.blit(self.score_image, self.score_rect)
        self.screen.blit(self.high_score_image, self.high_score_rect)
        self.screen.blit(self.level_image, self.level_rect)
        self.mini_ships.draw(self.screen)

        self.screen.blit(self.big_bullets_str_image, self.big_bullets_rect)
        self.screen.blit(
            self.piercing_bullets_str_image, self.piercing_bullets_rect
        )
        self.draw_big_bullet_ico()
        self.draw_piercing_bullet_ico()

    def prep_score(self):
        """将得分转换为一幅渲染的图像"""
        score_str = "Score: {:,}".format(int(round(self.stats.score, -1)))

        self.score_image = self.font.render(
            score_str, False, self.text_color, self.settings.bg_color
        )

        # 在屏幕右上角显示得分
        self.score_rect = self.score_image.get_rect()
        self.score_rect.right = self.screen_rect.right - 10
        self.score_rect.top = 10

    def prep_high_score(self):
        """将最高分渲染图像"""
        high_score = int(round(self.stats.high_score, -1))
        high_score_str = f"High Score: {high_score:,}"
        self.high_score_image = self.font.render(
            high_score_str, False, self.text_color, self.settings.bg_color
        )

        # 将最高分放在屏幕中央
        self.high_score_rect = self.high_score_image.get_rect()
        self.high_score_rect.centerx = self.screen_rect.centerx + 70
        self.high_score_rect.y = 10

    def check_high_score(self):
        """检查是否诞生了新的最高分"""
        if self.stats.score > self.stats.high_score:
            self.stats.high_score = self.stats.score
            self.prep_high_score()

    def prep_level(self):
        level_str = f"Level {self.stats.level}"
        self.level_image = self.font.render(
            level_str, False, self.text_color, self.settings.bg_color
        )

        # 将等级放在得分下方
        self.level_rect = self.level_image.get_rect()
        self.level_rect.right = self.score_rect.right
        self.level_rect.top = self.score_rect.bottom + 10

    def prep_mini_ships(self):
        """显示还余下多少飞船"""
        self.mini_ships = Group()
        for ship_number in range(self.stats.ships_left):
            mini_ship = MiniShip(self.ai_game)
            mini_ship.rect.x = 10 + ship_number * mini_ship.rect.width * 1.15
            mini_ship.rect.y = 10
            self.mini_ships.add(mini_ship)

    def prep_big_bullets(self):
        big_bullets_str = "X " + str(self.ai_game.stats.big_bullet)
        self.big_bullets_str_image = self.font.render(
            big_bullets_str, False, self.text_color, self.settings.bg_color
        )

        self.big_bullets_rect = self.big_bullets_str_image.get_rect()
        self.big_bullets_rect.y = self.score_rect.y + 10
        self.big_bullets_rect.x = 265

    def draw_big_bullet_ico(self):
        mini_big_bullet_image = pygame.image.load(
            "images/big_bullet_ico.png"
        ).convert()
        mini_big_bullet_rect = mini_big_bullet_image.get_rect()
        mini_big_bullet_rect.x, mini_big_bullet_rect.y = 215, 10
        self.screen.blit(mini_big_bullet_image, mini_big_bullet_rect)

    def prep_piercing_bullets(self):
        piercing_bullets_str = "X " + str(self.ai_game.stats.piercing_bullet)
        self.piercing_bullets_str_image = self.font.render(
            piercing_bullets_str,
            False,
            self.text_color,
            self.settings.bg_color,
        )

        self.piercing_bullets_rect = self.piercing_bullets_str_image.get_rect()
        self.piercing_bullets_rect.y = self.score_rect.y + 10
        self.piercing_bullets_rect.x = 355

    def draw_piercing_bullet_ico(self):
        mini_piercing_bullet_image = pygame.image.load(
            "images/piercing_bullet_ico.png"
        ).convert()
        mini_piercing_bullet_rect = mini_piercing_bullet_image.get_rect()
        mini_piercing_bullet_rect.x, mini_piercing_bullet_rect.y = 315, 10
        self.screen.blit(mini_piercing_bullet_image, mini_piercing_bullet_rect)
