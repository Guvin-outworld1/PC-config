import os
import random
import sys

os.chdir(os.path.dirname(os.path.abspath(__file__)))

from utils.alien import *
from utils.bullet import *
from utils.button import Button
from utils.choose_bgm import *
from utils.difficulty_button import *
from utils.game_stats import GameStats
from utils.scoreboard import ScoreBoard
from utils.settings import Settings
from utils.ship import Ship


class AlienInvasion(object):
    """外星人入侵：管理游戏资源和行为的类"""

    def __init__(self):
        """初始化游戏并创建游戏资源"""
        pygame.init()
        pygame.mixer.init()
        self.settings = Settings()

        self.screen = pygame.display.set_mode(
            (self.settings.screen_width, self.settings.screen_height)
        )
        pygame.display.set_caption("AlienInvasion(Easy)")

        # 创建一个用于存储游戏信息的实例并创建记分牌
        self.stats = GameStats(self)
        self.sb = ScoreBoard(self)
        
        # 初始化飞船无敌时间属性，0表示非无敌状态
        self.invincible_time = 0

        # 预载图像
        self.bullet_image = pygame.image.load("images/bullet.png").convert()
        self.big_bullet_image = pygame.image.load(
            "images/big_bullet.png"
        ).convert()
        self.piercing_bullet_image = pygame.image.load(
            "images/piercing_bullet.png"
        ).convert()

        self.alien_image = pygame.image.load("images/alien.png").convert()
        self.give_bullet_alien_image = pygame.image.load(
            "images/give_bullet_alien.png"
        ).convert()
        self.give_piercing_bullet_alien_image = pygame.image.load(
            "images/give_piercing_bullet_alien.png"
        ).convert()

        # 创建精灵
        self.ship = Ship(self)
        self.bullets = pygame.sprite.Group()
        self.aliens = pygame.sprite.Group()

        # 创建Play按钮
        self.play_button = Button(self, "Play !")

        # 难度设置按钮
        self.choose_label = ChooseLabel(self)
        self.choice = Choice(self)
        self.easy = EasyButton(self)
        self.medium = MediumButton(self)
        self.difficult = DifficultButton(self)

        # 选择bgm按钮
        self.choose_bgm_label = ChooseBgmLabel(self)
        self.choice_bgm = ChoiceBgm(self)
        self.choose_bgm1 = ChooseBgm1(self)
        self.choose_bgm2 = ChooseBgm2(self)

        self.clock = pygame.time.Clock()

    def run_game(self):
        """开始游戏的主循环"""
        while True:
            self.clock.tick(61)
            self._check_event()

            if self.stats.game_active:
                self.ship.update()
                self._update_bullets()
                self._update_aliens()

            self._update_screen()

    def _check_event(self):
        # 监视键盘和鼠标
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                with open("utils/high_score.txt", "w") as f:
                    f.write(str(int(self.stats.high_score)))
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                self._check_keydown_events(event)
            elif event.type == pygame.KEYUP:
                self._check_keyup_events(event)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                self._check_play_button(mouse_pos)
                self._check_difficulty_button(mouse_pos)
                self._check_bgm_button(mouse_pos)

    def _check_play_button(self, mouse_pos):
        """在玩家单机Play按钮时开始游戏"""
        if (
            self.play_button.rect.collidepoint(mouse_pos)
            and not self.stats.game_active
        ):
            # 重置游戏设置
            self.settings.initialize_dynamic_settings()

            # 重置游戏统计信息
            self.stats.reset_stats()
            self.stats.game_active = True
            self.sb.prep_score()
            self.sb.prep_level()
            self.sb.prep_mini_ships()
            self.sb.prep_big_bullets()
            self.sb.prep_piercing_bullets()

            # 清空余下的外星人和子弹
            self.bullets.empty()
            self.aliens.empty()

            # 创建新的外星人群并让飞船居中
            self._create_fleet()
            self.ship.center_ship()

            # 隐藏鼠标光标
            pygame.mouse.set_visible(False)

            # 播放bgm
            if self.settings.play_bgm == "bgm1":
                self.settings.bgm1.play(-1)
            elif self.settings.play_bgm == "bgm2":
                self.settings.bgm2.play(-1)

    def _check_difficulty_button(self, mouse_pos):
        # 三种难度的按钮
        if (
            self.easy.rect.collidepoint(mouse_pos)
            and not self.stats.game_active
        ):
            self.settings.difficulty = 1
            self.choice.text = "Easy"
            self.choice.prep_choice_button()
            self.settings.increment = self.settings.easy_increment
            pygame.display.set_caption("AlienInvasion(Easy)")

        elif (
            self.medium.rect.collidepoint(mouse_pos)
            and not self.stats.game_active
        ):
            self.settings.difficulty = 2
            self.choice.text = "Medium"
            self.choice.prep_choice_button()
            self.settings.increment = self.settings.med_increment
            pygame.display.set_caption("AlienInvasion(Medium)")

        elif (
            self.difficult.rect.collidepoint(mouse_pos)
            and not self.stats.game_active
        ):
            self.settings.difficulty = 3
            self.choice.text = "Difficulty"
            self.choice.prep_choice_button()
            self.settings.increment = self.settings.diff_increment
            pygame.display.set_caption("AlienInvasion(Difficult)")

    def _check_bgm_button(self, mouse_pos):
        # 两种bgm按钮
        if (
            self.choose_bgm1.rect.collidepoint(mouse_pos)
            and not self.stats.game_active
        ):
            self.settings.play_bgm = "bgm1"
            self.choice_bgm.prep_choice_button()
        if (
            self.choose_bgm2.rect.collidepoint(mouse_pos)
            and not self.stats.game_active
        ):
            self.settings.play_bgm = "bgm2"
            self.choice_bgm.prep_choice_button()

    def _check_keydown_events(self, event):
        """响应按键"""
        if self.stats.game_active:
            if event.key == pygame.K_RIGHT:
                self.ship.moving_right = True
            elif event.key == pygame.K_LEFT:
                self.ship.moving_left = True
            elif event.key == pygame.K_SPACE or event.key == pygame.K_UP:
                self._fire_bullet()
            elif event.key == pygame.K_d or event.key == pygame.K_DOWN:
                self._fire_big_bullet()
            elif event.key == pygame.K_f:
                self._fire_piercing_bullet()
        elif event.key == pygame.K_q:
            with open("utils/high_score.txt", "w") as f:
                f.write(str(int(self.stats.high_score)))
            pygame.quit()
            sys.exit()

    def _check_keyup_events(self, event):
        """响应松开"""
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right = False
        if event.key == pygame.K_LEFT:
            self.ship.moving_left = False

    def _fire_bullet(self):
        """创建一颗子弹, 并将其加入编组bullets中"""
        if len(self.bullets) < self.settings.bullets_allowed:
            new_bullet = Bullet(self)
            self.settings.shoot_sound.play()
            self.bullets.add(new_bullet)

    def _fire_big_bullet(self):
        """创建一颗大子弹, 并将其加入编组bullets中"""
        if (
            len(self.bullets) < self.settings.bullets_allowed
            and self.stats.big_bullet > 0
        ):
            self.stats.big_bullet -= 1
            self.sb.prep_big_bullets()
            new_bullet = BigBullet(self)
            self.settings.shoot_sound.play()
            self.bullets.add(new_bullet)

    def _fire_piercing_bullet(self):
        """创建一颗透心凉子弹, 并将其加入编组bullets中"""
        if (
            len(self.bullets) < self.settings.bullets_allowed
            and self.stats.piercing_bullet > 0
        ):
            self.stats.piercing_bullet -= 1
            self.sb.prep_piercing_bullets()
            new_bullet = PiercingBullet(self)
            self.settings.shoot_sound.play()
            self.bullets.add(new_bullet)

    def _update_bullets(self):
        """更新子弹的位置并删除消失的子弹"""
        self.bullets.update()

        for bullet in self.bullets.copy():
            if bullet.rect.bottom < 0:
                self.bullets.remove(bullet)

        self._check_bullet_alien_collision()

    def _check_bullet_alien_collision(self):
        """响应子弹和外星人发生碰撞"""
        # 检查当子弹击中外星人时, 删除相应的
        collision = pygame.sprite.groupcollide(
            self.bullets, self.aliens, False, True
        )

        if collision:
            for bullet in list(collision.keys()):
                if isinstance(bullet, PiercingBullet):
                    pass
                else:
                    bullet.kill()

            for hit_alien in collision.values():
                if any(
                    isinstance(alien, GiveBulletAlien) for alien in hit_alien
                ):
                    self.stats.big_bullet += 1
                    self.sb.prep_big_bullets()
                    self.settings.give_bullet_alien_explosion.play()

                elif any(
                    isinstance(alien, GivePiercingBulletAlien)
                    for alien in hit_alien
                ):
                    self.stats.piercing_bullet += 1
                    self.sb.prep_piercing_bullets()
                    self.settings.give_bullet_alien_explosion.play()

                else:
                    self.settings.explosion_sound.play()

                for alien in collision.values():
                    self.stats.score += self.settings.alien_points * len(alien)
                self.sb.prep_score()
                self.sb.check_high_score()

        if not self.aliens:
            # 删除现有子弹并创建一群外星人
            self.bullets.empty()
            self._create_fleet()
            self.settings.increase_speed()

            # 提供等级
            self.stats.level += 1
            self.sb.prep_level()

    def _ship_hit(self):
        """响应飞船被外星人撞到"""

        # 首先检查是否还有剩余飞船
        if self.stats.ships_left > 0:
            # 将ship_left减一并更新剩余飞船数
            self.stats.ships_left -= 1
            self.sb.prep_mini_ships()

            # 播放音效
            self.settings.ship_hit_sound.play()
            # 暂停
            pygame.time.delay(700)

            # 清空余下的外星人和子弹
            self.aliens.empty()
            self.bullets.empty()

            # 将飞船放到屏幕底部中央
            self.ship.center_ship()
            # 创建新的一群外星人
            self._create_fleet()
            
            # 设置飞船无敌时间（约2秒，假设60fps）
            self.invincible_time = 120

        else:
            # 播放音效
            self.settings.ship_hit_sound.play()
            # 暂停
            pygame.time.delay(700)
            
            # 清空余下的外星人和子弹
            self.aliens.empty()
            self.bullets.empty()
            
            self.stats.game_active = False
            with open("utils/high_score.txt", "w") as f:
                f.write(str(self.stats.high_score))
            pygame.mouse.set_visible(True)

            pygame.mixer.stop()

    def _create_fleet(self):
        """创造外星人群"""

        # 创造一个外星人
        # 外星人的间距为之宽度
        alien = Alien(self)
        alien_width, alien_height = alien.rect.size
        available_space_x = self.settings.screen_width - alien_width * 2
        number_alien_x = available_space_x // (2 * alien_width)

        # 计算屏幕可容纳多少外星人
        available_space_y = (
            self.settings.screen_width
            - 5 * alien_height
            - 2 * self.ship.rect.height
        )
        number_rows = available_space_y // (2 * alien_height)

        # 创建三个give_bullet_alien及一个give_piercing_bullet_alien
        is_give_bullet_alien = random.sample(range(1, 46), 4)

        # 创建外星人群
        for row_number in range(number_rows):
            for alien_number in range(number_alien_x):
                self._create_alien(
                    alien_number, row_number, is_give_bullet_alien
                )

    def _create_alien(self, alien_number, row_number, is_give_bullet_alien):
        """创建一个外星人并将其放在当前行"""
        alien = Alien(self)
        give_bullet_alien = GiveBulletAlien(self)
        give_piercing_bullet_alien = GivePiercingBulletAlien(self)
        if row_number * 9 + alien_number + 1 in is_give_bullet_alien[:-1]:
            give_bullet_alien_width = give_bullet_alien.rect.width
            give_bullet_alien.x = (
                give_bullet_alien_width
                + 2 * give_bullet_alien_width * alien_number
            )
            give_bullet_alien.rect.x = give_bullet_alien.x
            give_bullet_alien.rect.y = (
                2 * give_bullet_alien.rect.height
                + 2 * give_bullet_alien.rect.height * row_number
            )
            self.aliens.add(give_bullet_alien)

        elif row_number * 9 + alien_number + 1 == is_give_bullet_alien[-1]:
            give_piercing_bullet_alien_width = (
                give_piercing_bullet_alien.rect.width
            )
            give_piercing_bullet_alien.x = (
                give_piercing_bullet_alien_width
                + 2 * give_piercing_bullet_alien_width * alien_number
            )
            give_piercing_bullet_alien.rect.x = give_piercing_bullet_alien.x
            give_piercing_bullet_alien.rect.y = (
                2 * give_piercing_bullet_alien.rect.height
                + 2 * give_piercing_bullet_alien.rect.height * row_number
            )
            self.aliens.add(give_piercing_bullet_alien)

        else:
            alien_width = alien.rect.width
            alien.x = alien_width + 2 * alien_width * alien_number
            alien.rect.x = alien.x
            alien.rect.y = (
                2 * alien.rect.height + 2 * alien.rect.height * row_number
            )
            self.aliens.add(alien)

    def _update_aliens(self):
        """更新外星人群所有外星人的位置"""
        self._check_fleet_edges()
        self.aliens.update()

        # 检测外星人和飞船之间的碰撞
        if hasattr(self, 'invincible_time') and self.invincible_time > 0:
            self.invincible_time -= 1
        else:
            if pygame.sprite.spritecollideany(self.ship, self.aliens):
                self._ship_hit()

        # 检查是否有外星人到底底部
        self._check_aliens_bottom()

    def _check_aliens_bottom(self):
        """检测是否有外星人撞到了屏幕地部"""
        screen_rect = self.screen.get_rect()
        for alien in self.aliens:
            if alien.rect.bottom >= screen_rect.bottom:
                # 与撞到飞船同操作
                self._ship_hit()
                break

    def _check_fleet_edges(self):
        """外星人碰到边缘时的措施"""
        for alien in self.aliens.sprites():
            if alien.check_edges():
                self._change_fleet_direction()
                break

    def _change_fleet_direction(self):
        """将外星人下移并改变方向"""
        for alien in self.aliens.sprites():
            alien.rect.y += self.settings.fleet_drop_speed
        self.settings.fleet_direction *= -1

    def _update_screen(self):
        """更新屏幕上的图像，并切换到新屏幕"""
        self.screen.fill(self.settings.bg_color)
        self.ship.blitme()
        for bullet in self.bullets.sprites():
            bullet.draw_bullet()
        self.aliens.draw(self.screen)

        # 显示得分
        self.sb.show_score()

        # 如果游戏处于非活动状态，绘制Play及难度选择按钮
        if not self.stats.game_active:
            self.play_button.draw_button()

            # 选择难度
            self.choose_label.draw_choose_button()
            self.easy.draw_easy_button()
            self.medium.draw_medium_button()
            self.difficult.draw_difficult_button()
            self.choice.draw_choice_button()

            # 选择bgm
            self.choose_bgm_label.draw_choose_button()
            self.choose_bgm1.draw_bgm1()
            self.choose_bgm2.draw_bgm2()
            self.choice_bgm.draw_choice_button()

        pygame.display.flip()


if __name__ == "__main__":
    ai = AlienInvasion()
    ai.run_game()
